﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace GeometryMotionVisualization
{
    public partial class MainWindow : Window
    {
        private double _speed = 1.0;
        private double _squareX = 200;
        private double _squareY = 200;
        private double _circleX = 300;
        private double _circleY = 200;
        private double _squareDeltaX;
        private double _squareDeltaY;
        private double _circleDeltaX;
        private double _circleDeltaY;
        private DispatcherTimer _timer;
        private Random _random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            CreateShapes();
            StartAnimation();
        }

        private void CreateShapes()
        {
            Rectangle rect = new Rectangle
            {
                Width = 50,
                Height = 50,
                Fill = Brushes.Blue
            };
            Canvas.SetLeft(rect, _squareX);
            Canvas.SetTop(rect, _squareY);
            canvas.Children.Add(rect);

            Ellipse ellipse = new Ellipse
            {
                Width = 50,
                Height = 50,
                Fill = Brushes.Red
            };
            Canvas.SetLeft(ellipse, _circleX);
            Canvas.SetTop(ellipse, _circleY);
            canvas.Children.Add(ellipse);
        }

        private void StartAnimation()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(10);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (_speed < 5.0)
            {
                _speed += 0.01;
            }
            _squareDeltaX += (_random.NextDouble() * 0.4 - 0.2);
            _squareDeltaY += (_random.NextDouble() * 0.4 - 0.2);

            _squareDeltaX = Math.Max(-2, Math.Min(2, _squareDeltaX));
            _squareDeltaY = Math.Max(-2, Math.Min(2, _squareDeltaY));

            _circleDeltaX += (_random.NextDouble() * 0.4 - 0.2);
            _circleDeltaY += (_random.NextDouble() * 0.4 - 0.2);

            _circleDeltaX = Math.Max(-2, Math.Min(2, _circleDeltaX));
            _circleDeltaY = Math.Max(-2, Math.Min(2, _circleDeltaY));

            _squareX += _squareDeltaX * _speed;
            _squareY += _squareDeltaY * _speed;

            _circleX += _circleDeltaX * _speed;
            _circleY += _circleDeltaY * _speed;

            if (_squareX < 0 || _squareX > canvas.ActualWidth - 50)
            {
                _squareDeltaX *= -1;
            }
            if (_squareY < 0 || _squareY > canvas.ActualHeight - 50)
            {
                _squareDeltaY *= -1;
            }

            if (_circleX < 0 || _circleX > canvas.ActualWidth - 50)
            {
                _circleDeltaX *= -1;
            }
            if (_circleY < 0 || _circleY > canvas.ActualHeight - 50)
            {
                _circleDeltaY *= -1;
            }
            
            Canvas.SetLeft(canvas.Children[0], _squareX);
            Canvas.SetTop(canvas.Children[0], _squareY);
            
            Canvas.SetLeft(canvas.Children[1], _circleX);
            Canvas.SetTop(canvas.Children[1], _circleY);
        }
    }
}





